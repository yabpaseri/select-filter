(function main() {
  Object.defineProperty(MouseEvent.prototype, "commandKey", {
    get() {
      const isMac = window.navigator.userAgent.includes("Mac");
      return isMac && this.metaKey || !isMac && this.ctrlKey;
    }
  });
})();
